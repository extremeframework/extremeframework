<?php
return array(
    ////////////////////////////////////////////////////////
    // Package information
    ////////////////////////////////////////////////////////
    'name' => 'Admin Commerce',
    'code' => 'admin.commerce',
    'category' => 'business',
    'image' => 'icon.png',
    'description' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
    'entry_path' => 'adminorder',
    'author' => 'Sample Author',
    'version' => '1.0.0',
    'package_url' => 'http://www.example.org',
    'author_url' => 'http://www.example.org',

    ////////////////////////////////////////////////////////
    // Package shortcuts
    ////////////////////////////////////////////////////////
    'shortcuts' => array(
        
    ),

    ////////////////////////////////////////////////////////
    // Permissions of the package. Each item is a permission
    // set (its key is the set name, its value is an array
    // of modules and their corresponding allowed actions)
    ////////////////////////////////////////////////////////
    'permissions' => array(
        'Basic' => array(
            'adminorder' => 'menu list view new edit delete search',
            'paymenttype' => 'menu list view new edit delete search',
            'adminorderstatus' => 'menu list view new edit delete search',
            'adminorderitem' => 'menu list view new edit delete search',
            'adminproduct' => 'menu list view new edit delete search'
        ),
//        'Advanced' => array(
//            'samplemodule' => 'list view edit delete search import export'
//        )
    ),

    ////////////////////////////////////////////////////////
    // Package menu
    ////////////////////////////////////////////////////////
    'menu' => array(
//        ['name' => 'Sample', 'module' => 'samplemodule', 'path' => ''],
//        ['name' => 'Sample sub-menu', 'module' => '', 'path' => 'a-certain-path', 'parent' => 0],
    ),
);