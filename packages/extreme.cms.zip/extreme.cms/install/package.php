<?php
return array(
    ////////////////////////////////////////////////////////
    // Package information
    ////////////////////////////////////////////////////////
    'name' => 'Extreme CMS',
    'code' => 'extreme.cms',
    'category' => 'business',
    'image' => 'icon.png',
    'description' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
    'entry_path' => '',
    'author' => 'Sample Author',
    'version' => '1.0.0',
    'package_url' => 'http://www.example.org',
    'author_url' => 'http://www.example.org',

    ////////////////////////////////////////////////////////
    // Package shortcuts
    ////////////////////////////////////////////////////////
    'shortcuts' => array(
        
    ),

    ////////////////////////////////////////////////////////
    // Permissions of the package. Each item is a permission
    // set (its key is the set name, its value is an array
    // of modules and their corresponding allowed actions)
    ////////////////////////////////////////////////////////
    'permissions' => array(
        'Basic' => array(
            'menu' => 'menu list view new edit delete search',
            'menuitem' => 'menu list view new edit delete search',
            'page' => 'menu list view new edit delete search',
            'pagegallery' => 'menu list view new edit delete search',
            'pagelink' => 'menu list view new edit delete search',
            'pagelinktype' => 'menu list view new edit delete search',
            'pagesection' => 'menu list view new edit delete search',
            'pagewidget' => 'menu list view new edit delete search',
            'widgettype' => 'menu list view new edit delete search',
            'widgetposition' => 'menu list view new edit delete search',
            'post' => 'menu list view new edit delete search',
            'posttype' => 'menu list view new edit delete search',
            'postcategory' => 'menu list view new edit delete search',
            'postgallery' => 'menu list view new edit delete search',
            'postrelation' => 'menu list view new edit delete search',
            'postrelationtype' => 'menu list view new edit delete search',
            'postsection' => 'menu list view new edit delete search',
            'template' => 'menu list view new edit delete search'
        ),
//        'Advanced' => array(
//            'samplemodule' => 'list view edit delete search import export'
//        )
    ),

    ////////////////////////////////////////////////////////
    // Package menu
    ////////////////////////////////////////////////////////
    'menu' => array(
//        ['name' => 'Sample', 'module' => 'samplemodule', 'path' => ''],
//        ['name' => 'Sample sub-menu', 'module' => '', 'path' => 'a-certain-path', 'parent' => 0],
    ),
);